$("document").ready(function() {
  $("form[name='registration']").validate({
   
    rules: {
      firstname:{
        required:true,
        minlength:3,
        maxlength:12,
        regex:"[^0-9]$"
      },
      email: {
        required: true,
        email: true
      },
      date:{
        required:true
      },
      password: {
        required: true,
        minlength: 5,
      },
      subscribe:{
        required:true,
      },
      news:{
        required:true,
      },
    },
    messages: {
      firstname:{
        required:"Enter firstname",
        minlength:"minlength3",
        maxlength:"maxlength12",
        regex:"do not insert number"
      },
      email:{
        required:"Enter Email id",
        email: "Please enter a valid email address"
      },
      date:{
        required:"select date format"
      },
      password: {
        required: "Please Enter password",
        minlength: "minlength 5",
      },
      subscribe:{
        required:"choose the subscribtion option",
      },
      news:{
         required:"Please select atleast 1 news"
      },
    },
    errorElement : 'div',
      submitHandler: function(form) {
        form.submit();
      },
       highlight: function (element, errorClass) {
        $(element).closest('.form-group').addClass('has-error');
      },
      unhighlight: function (element, errorClass) {
        $(element).closest('.form-group').removeClass('has-error');
      },
      errorPlacement: function(error, element) {
        //error.insertAfter(element);
        error.appendTo(element.parent());       
      }

  });
        
    $("#datepicker").datepicker({
      changeYear:true,
      dateFormat: "dd-mm-yy",
      changeMonth: true,
    });

    $(".answer").hide();
    $(".news").click(function() {
      if($(this).is(":checked")) {
          $(".answer").show();

      } else {
          $(".answer").hide();
      }
    });
});

$.validator.addMethod(
      "regex",
      function(value, element, regexp) {
          var check = false;
          var re = new RegExp(regexp);
          return this.optional(element) || re.test(value);
      },""
);