<?php

	echo json_encode(array(
		"name"=>"Harshit",
		"email"=>"harshitshah@gmail.com"
	));
?>	