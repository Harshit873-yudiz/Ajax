//Send and Retrive User Data using Json
$("document").ready(function(){	
	$("#jsonsubmit").click(function(){
		$.ajax({
			url:"files/jsonread.php",
			type:"POST",
			data:"name="+name,
			//dataType: 'json',
			success:function(response){

				var json1 = response;
         		var obj = JSON.parse(json1);
          		console.log(obj);
				$("#jsoncontent").html(obj);
			}
		});
	});
});		 