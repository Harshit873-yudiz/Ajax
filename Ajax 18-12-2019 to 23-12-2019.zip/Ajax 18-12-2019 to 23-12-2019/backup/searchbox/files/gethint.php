 <?php

 	 $a=array(
  'AP' => 'Andhra Pradesh',
 'AR' => 'Arunachal Pradesh',
 'AS' => 'Assam',
 'BR' => 'Bihar',
 'CT' => 'Chhattisgarh',
 'GA' => 'Goa',
 'GJ' => 'Gujarat',
 'HR' => 'Haryana',
 'HP' => 'Himachal Pradesh',
 'JK' => 'Jammu & Kashmir',
 'JH' => 'Jharkhand',
 'KA' => 'Karnataka',
 'KL' => 'Kerala',
 'MP' => 'Madhya Pradesh',
 'MH' => 'Maharashtra',
 'MN' => 'Manipur',
 'ML' => 'Meghalaya',
 'MZ' => 'Mizoram',
 'NL' => 'Nagaland',
 'OR' => 'Odisha',
 'PB' => 'Punjab',
 'RJ' => 'Rajasthan',
 'SK' => 'Sikkim',
 'TN' => 'Tamil Nadu',
 'TR' => 'Tripura',
 'UK' => 'Uttarakhand',
 'UP' => 'Uttar Pradesh',
 'WB' => 'West Bengal',
 	 );
 	 //echo a;
	 $state = $_POST["state"];
	 //echo $state;
	 $hint="";

	 if ($state !== "") {
  		$state = strtolower($state);
  		$len=strlen($state);
  		foreach($a as $name) {
    		if (stristr($state, substr($name, 0, $len))) {
      			if ($hint === "") {
        			$hint = $name;
      			} else {
        			$hint .= ", $name";
      			}
    		}
  		}
  	}	
	echo $hint === "" ? "Enter Value not found" : $hint;
?> 