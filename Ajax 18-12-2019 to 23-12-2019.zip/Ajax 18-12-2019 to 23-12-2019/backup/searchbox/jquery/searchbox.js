$("document").ready(function(){
  
   $("#showHint").keyup(function(){
      var name=$("#showHint").val();
      $.ajax({  
        url: "files/gethint.php",
        type:"POST",
        data:"state="+name,
        success: function(result){
           $("#txtHint").html(result);
            console.log(result);
        }
      });
    });
});
