$("document").ready(function(){
	
	$("#datepicker").datepicker({
		changeYear:true,
		dateFormat: "dd-mm-yy",
        changeMonth: true,
	});
	$("#datepicker").change(function(){
		$("#data1").html($("#datepicker").val());
	});

	//txt file read
	$("#txt").click(function(){
	    $.ajax({url: "files/demo.txt",
	    success: function(result){
	        $("#div1").html(result);
	    }});
	});

	//php file read
	$("#php").click(function(){
	    $.ajax({url: "files/demo.php",
	    success: function(result){
	      $("#div2").html(result);
	    }});
	});

	//php user name file read
	$("#unamephp").click(function(){
	    $.ajax({	
    	url: "files/user.php",
    	type:"POST",
    	data:{name:"HARSHIT"},
    	success: function(result){
      		$("#div3").html(result);
      		console.log(result);
    	}});
	});

	//send request to php
	$("#send").click(function(){
		var name=$("#name").val();
		$.ajax({	
	    	url: "files/user.php",
	    	type:"POST",
	    	data:'name='+name,
	    	success:function(data){
    			$("#content").html(data);
    		}
		});
	});

	//datepicker send and retrive php
    $( "#startDate" ).datepicker({
    	dateFormat: "dd-mm-yy",
        changeMonth: true,
        changeYear:true,
        success: function( selectedDate ) {
            $( "#startDate" ).datepicker( "option", "maxDate", selectedDate );   
    	}
    });
    $("#submit").click(function(){
    	var startDate=$("#startDate").val();
    	$.ajax({
    		url:"files/user.php",
    		type:"POST",
    		data:'startDate='+startDate,
    		success:function(data){
    			$("#content1").html(data);
    		}
    	});
    });
});