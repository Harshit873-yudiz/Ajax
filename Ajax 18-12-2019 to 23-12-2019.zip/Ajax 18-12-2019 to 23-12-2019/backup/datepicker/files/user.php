<?php
	if (isset($_POST['name'])) {
		$name=$_POST['name'];
		echo $name;
	}

	else if(isset($_POST['startDate'])){
		$startdate=$_POST['startDate'];
		echo "your Selected Date is:";
		echo $startdate;
	}
	else{
		echo " not found";
	}
?>