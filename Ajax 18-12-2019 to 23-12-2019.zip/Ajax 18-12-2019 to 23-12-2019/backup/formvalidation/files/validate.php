<?php

	if(isset($_POST['selectedstate'])){
		$selectedstate=$_POST['selectedstate'];
		echo $selectedstate;
	}
	else{
		echo "not found";
	}
		if($selectedstate=='guj'){
		echo "

			  <option value='ahmedabad'>Ahmedabad</option>
		      <option value='rajkot'>Rajkot</option>
		";
	}
	if($selectedstate=='raj'){
		echo "
			  <option value='udaypur'>Udaypur</option>
		      <option value='jaypur'>Jaypur</option>
		";
	}
?>