$("document").ready(function() {
  $("form[name='registration']").validate({
    rules: {
      firstname:{
        required:true,
        minlength:3,
        maxlength:12,
        regex:"[^0-9]$"
      },
      email: {
        required: true,
        maxlength:150,
        email: true
      },
      date:{
        required:true
      },
      password: {
        required: true,
        minlength: 5,
      },
      profile_image:{
        required:true,
        extension:"jpg|jpeg|png"
      },
      weburl:{
         required: true,
         url: true
      },
      state:{
        required:true
      },
      price:{
        required:true,
        regex:"[^a-zA-Z]"
      },
      news:{
        required:true
      }
    },
    messages: {
      firstname:{
        required:"Enter firstname",
        minlength:"minlength3",
        maxlength:"maxlength12",
        regex:"do not insert number"
      },
      email:{
        required:"Enter Email id",
        email: "Please enter a valid email address",
        maxlength:"only 150 char"
      },
      date:{
        required:"select date format"
      },
      password: {
        required: "Please Enter password",
        minlength: "minlength 5",
      },
      profile_image:{
        required:"select img file",
        extension:"use only jpg,png,jpeg file"
      },
      weburl:{
         required: "url required",
         url:"use http:// or https://"
      },
      state:{
        required:" Please select state"
      },
      price:{
        required:"Please Enter Price",
        regex:"do not insert char"
      },
      news:{
         required:"Please select atleast 1 news"
      }
    },
    errorElement : 'div',
      submitHandler: function(form) {
        $("form")[0].reset();
        //form.submit();
      },
       highlight: function (element, errorClass) {
        $(element).closest('.form-group').addClass('has-error');
      },
      unhighlight: function (element, errorClass) {
        $(element).closest('.form-group').removeClass('has-error');
      },
      errorPlacement: function(error, element) {
        //error.insertAfter(element);
        error.appendTo(element.parent());       
      }

  });
  
    $("#datepicker").datepicker({
      changeYear:true,
      dateFormat: "dd-mm-yy",
      changeMonth: true,
    });
 
  
  $("select.state").change(function(){
        var selectedstate = $(this).children("option:selected").val();
        $.ajax({
           url: "files/validate.php",
           type:"POST",
           data:"selectedstate="+selectedstate,
           success:function(result){
            $("select.city").html(result);
           }
        });
    });

    $(".answer").hide();
    $(".news").click(function() {
      if($(this).is(":checked")) {
          $(".answer").show();

      } else {
          $(".answer").hide();
      }
    });
});

$.validator.addMethod(
      "regex",
      function(value, element, regexp) {
          var check = false;
          var re = new RegExp(regexp);
          return this.optional(element) || re.test(value);
      }
);